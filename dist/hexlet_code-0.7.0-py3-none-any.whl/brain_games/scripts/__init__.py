"""brain-games scripts."""
